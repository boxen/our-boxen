# Pinned Homebrew Formulae

These formulae are for local dev packages where we want to control the
exact version. They're installed as a brew tap. In most cases caveats
and configuration files managed by setup have been removed. When
necessary, formula deps have been adjusted to point at our pinned
version, e.g., `github/brews/depname`.
