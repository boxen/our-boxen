# Configure and activate rbenv. You know, for rubies.

export RBENV_ROOT=$BOXEN_HOME/rbenv
eval "$(rbenv init -)"
