# Screenhero Puppet Module for Boxen

Install [Screenhero](http://www.screenhero.com/index.html), a screen-sharing application.

## Usage

```puppet
include screenhero
```

## Required Puppet Modules

None.