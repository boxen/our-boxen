# libpng Puppet Module for Boxen

Installs libpng.

[![Build Status](https://travis-ci.org/mattheath/puppet-libpng.png?branch=master)](https://travis-ci.org/mattheath/puppet-libpng)

## Usage

```puppet
include libpng
```

## Required Puppet Modules

* `boxen`
* `homebrew`
