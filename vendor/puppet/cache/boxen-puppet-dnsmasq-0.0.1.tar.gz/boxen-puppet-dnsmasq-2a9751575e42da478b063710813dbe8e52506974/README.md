# DNSMasq Puppet Module for Boxen

Requires the `boxen` puppet module.

## Usage

```puppet
include dnsmasq
```
