# GCC Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-gcc.png?branch=master)](https://travis-ci.org/boxen/puppet-gcc)

## Usage

```puppet
include gcc
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`

