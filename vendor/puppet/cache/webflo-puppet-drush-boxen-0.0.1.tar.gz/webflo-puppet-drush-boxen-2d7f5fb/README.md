# Drush Puppet Module for Boxen

Requires the following boxen modules:

## Usage

```puppet
include drush
```

## Required Puppet Modules

* boxen
* homebrew

