# MacVim Puppet Module for Boxen

## Usage

```puppet
include macvim
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib

Also requires a full Xcode install.

