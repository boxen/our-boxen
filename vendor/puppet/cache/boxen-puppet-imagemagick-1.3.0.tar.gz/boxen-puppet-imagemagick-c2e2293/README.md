# ImageMagick Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-imagemagick.png?branch=master)](https://travis-ci.org/boxen/puppet-imagemagick)

## Usage

```puppet
include imagemagick
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
* xquartz
