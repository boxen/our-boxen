require "cmd/install"

# A custom Homebrew command that loads our bottle hooks.
Homebrew.install
