# XQuartz Puppet Module for Boxen

## Usage

```puppet
include xquartz
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
