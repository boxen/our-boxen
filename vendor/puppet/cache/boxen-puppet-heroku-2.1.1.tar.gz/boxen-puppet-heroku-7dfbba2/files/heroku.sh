# Add Heroku bins to PATH

export PATH="$BOXEN_HOME/heroku/bin:$PATH"
