# Puppet nvm for Boxen

FIXME: update me bro

