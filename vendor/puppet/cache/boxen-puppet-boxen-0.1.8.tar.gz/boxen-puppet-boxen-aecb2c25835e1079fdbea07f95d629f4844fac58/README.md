# Boxen Puppet Module

This includes various components required for boxen to run properly.

## Developing

Write code.

Run `script/cibuild`.

