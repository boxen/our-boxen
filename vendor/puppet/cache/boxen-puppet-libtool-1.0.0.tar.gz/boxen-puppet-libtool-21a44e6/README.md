# LibTool Puppet Module for Boxen

## Usage

```puppet
include libtool
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
