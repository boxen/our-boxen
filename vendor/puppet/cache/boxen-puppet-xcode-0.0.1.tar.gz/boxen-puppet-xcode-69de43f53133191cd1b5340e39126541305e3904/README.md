# XCode Puppet Module for Boxen

Installs the XCode **command line tools**.

Requires the following boxen modules:

* `boxen`

## Usage

```puppet
include xcode
```