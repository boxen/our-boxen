# Autoconf Puppet Module for Boxen

Install [autoconf](http://www.gnu.org/software/autoconf), your
favorite build and release framework.

## Usage

```puppet
include autoconf
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
