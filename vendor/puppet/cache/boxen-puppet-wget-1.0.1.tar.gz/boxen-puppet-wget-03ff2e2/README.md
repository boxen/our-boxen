# WGet Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-wget.png?branch=master)](https://travis-ci.org/boxen/puppet-wget)

Requires the following boxen modules:

## Usage

```puppet
include wget
```

## Required Puppet Modules

* boxen
* homebrew

