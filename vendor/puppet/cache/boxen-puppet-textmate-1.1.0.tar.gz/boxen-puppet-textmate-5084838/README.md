# TextMate Puppet Module for Boxen

## Usage

TextMate 1.5:

```puppet
include textmate
```

TextMate 2:

```puppet
include textmate2::release  # normal release
include textmate2::beta     # beta releases
include textmate2::nightly  # nightly releases
```

## Required Puppet Modules

* boxen
