# CMake Puppet Module for Boxen

Installs CMake.

[![Build Status](https://travis-ci.org/tommetge/puppet-cmake.png?branch=master)](https://travis-ci.org/tommetge/puppet-cmake)

## Usage

```puppet
include cmake
```

## Required Puppet Modules

* `boxen`
