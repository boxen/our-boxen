# SizeUp Puppet Module for Boxen

## Usage

```puppet
include sizeup
```

## Required Puppet Modules

* boxen

