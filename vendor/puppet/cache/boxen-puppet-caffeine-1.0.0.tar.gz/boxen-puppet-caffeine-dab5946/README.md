# Caffeine Puppet Module for Boxen

Install [Caffeine](http://lightheadsw.com/caffeine), insomnia for your Mac.

## Usage

```puppet
include caffeine
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
