# OpenSSL Puppet Module for Boxen

## Usage

```puppet
include openssl
```
