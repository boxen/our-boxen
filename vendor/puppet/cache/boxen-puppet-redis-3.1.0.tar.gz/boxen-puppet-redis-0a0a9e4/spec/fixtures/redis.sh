# Let the env know where Redis runs.

export BOXEN_REDIS_PORT=16379
export BOXEN_REDIS_URL="redis://localhost:$BOXEN_REDIS_PORT/"
