# Airfoil Puppet Module for Boxen

Requires the following boxen modules:

* [boxen](https://github.com/boxen/puppet-boxen)

## Usage

```puppet
include airfoil
```

## Developing

Write code.

Run `script/cibuild`.
