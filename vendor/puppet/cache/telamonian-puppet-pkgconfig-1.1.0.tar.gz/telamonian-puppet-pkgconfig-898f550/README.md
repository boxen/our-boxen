# Pkgconfig Puppet Module for Boxen

[![Build Status](https://travis-ci.org/telamonian/puppet-pkgconfig.png?branch=master)](https://travis-ci.org/telamonian/puppet-pkgconfig)

## Usage

```puppet
include pkgconfig
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
