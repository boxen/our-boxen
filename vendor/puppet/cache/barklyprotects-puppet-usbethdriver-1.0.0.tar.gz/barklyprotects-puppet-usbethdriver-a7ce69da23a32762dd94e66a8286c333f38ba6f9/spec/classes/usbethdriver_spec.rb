require 'spec_helper'

describe 'usbethdriver' do

  it do
    should contain_package('usbethdriver').with({
      :source   => 'https://s3.amazonaws.com/cylent-boxen/drivers/AX88179_178A.dmg',
      :provider => 'pkgdmg'
    })
  end
end
