#USB Ethernet Dongle Drivers Puppet Module for Boxen

## What's this for?
This is a driver installation on OSX for the Cable Matters Gigabit USB 3.0 Ethernet adapter. Provided is the driver for the AX88179/AX88178A device.
This can be validated when plugged in under the Apple -> About this Mac -> System Report -> Hardware -> USB.
You'll see the device listed in the above location.

## Usage

```puppet
include usbethdriver
```

## Required Puppet Modules

* boxen
