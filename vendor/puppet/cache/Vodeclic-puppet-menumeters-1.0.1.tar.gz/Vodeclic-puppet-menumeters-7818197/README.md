# MenuMeters Puppet Module for Boxen

Install [MenuMeters](http://www.ragingmenace.com/software/menumeters/)

## Usage

```puppet
include menumeters
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.