# Configure and activate rbenv. You know, for rubies.

export RBENV_ROOT=$GH_HOME/rbenv
eval "$(rbenv init -)"
