# Puppet nvm for Boxen

Installs nvm.

## Usage

``` puppet
include nvm
```

## Required Puppet Modules

* boxen
* stdlib

