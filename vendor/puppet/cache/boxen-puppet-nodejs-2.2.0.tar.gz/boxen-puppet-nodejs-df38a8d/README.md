# nodejs Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-nodejs.png?branch=master)](https://travis-ci.org/boxen/puppet-nodejs)

Using nodenv for nodejs version management,
automates installation and configuration of nodejs versions.

## Usage

``` puppet
# include some provided versions
include nodejs::v0_10
include nodejs::v0_8_8

# install any arbitrary nodejs version
nodejs { 'v0.10.1': }

# install some npm modules
nodejs::module { 'bower':
  node_version => 'v0.10'
}
```

## Required Puppet Modules

* boxen
* stdlib
