# Java SE 6 Puppet Module for Boxen

Install [Java SE 6](http://support.apple.com/kb/DL1572?viewlocale=en_US) using the official Apple package

## Usage

```puppet
include java6
```

## Required Puppet Modules

* `boxen`
