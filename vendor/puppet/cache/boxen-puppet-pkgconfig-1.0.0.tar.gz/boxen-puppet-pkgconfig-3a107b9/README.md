# Pkgconfig Puppet Module for Boxen

## Usage

```puppet
include pkgconfig
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
