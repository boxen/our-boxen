# Crashplan Puppet Module for Boxen

Install [Crashplan](http://www.crashplan.com/) on your Mac.

## Usage

```puppet
include crashplan
```

## Required Puppet Modules

* `boxen`
