# RBEnv Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`
* `homebrew`

## Usage

Just installs rbenv.
You probably want to use the puppet-ruby module instead.

```puppet
include rbenv
```