# PCRE Puppet Module for Boxen

## Usage

```puppet
include pcre
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`

