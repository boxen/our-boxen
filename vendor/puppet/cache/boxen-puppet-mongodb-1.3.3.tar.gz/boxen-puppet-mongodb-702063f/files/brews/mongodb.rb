require "formula"

class Mongodb < Formula
  homepage "https://www.mongodb.org/"

  stable do
    url "https://fastdl.mongodb.org/src/mongodb-src-r2.6.5.tar.gz"
    sha1 "f5a68505a0de1152b534d62a8f0147d258d503a0"

    # Review this patch with the next stable release.
    # Note it is a different patch to the one applied to all builds further below.
    # This is already fixed in the devel & HEAD builds.
    if MacOS.version == :yosemite
      patch do
        url "https://github.com/mongodb/mongo/commit/759b6e8.diff"
        sha1 "63d901ac81681fbe8b92dc918954b247990ab2fb"
      end
    end
  end

  version '2.6.5-boxen1'

  bottle do
    revision 2
    sha1 "e6da509908fdacf9eb0f16e850e0516cd0898072" => :yosemite
    sha1 "5ab96fe864e725461eea856e138417994f50bb32" => :mavericks
    sha1 "193e639b7b79fbb18cb2e0a6bbabfbc9b8cbc042" => :mountain_lion
  end

  devel do
    url "https://fastdl.mongodb.org/src/mongodb-src-r2.7.7.tar.gz"
    sha1 "ce223f5793bdf5b3e1420b0ede2f2403e9f94e5a"

    # Remove this with the next devel release. Already merged in HEAD.
    # https://github.com/mongodb/mongo/commit/8b8e90fb
    patch do
      url "https://github.com/mongodb/mongo/commit/8b8e90fb.diff"
      sha1 "9f9ce609c7692930976690cae68aa4fce1f8bca3"
    end
  end

  # HEAD is currently failing. See https://jira.mongodb.org/browse/SERVER-15555
  head "https://github.com/mongodb/mongo.git"

  option "with-boost", "Compile using installed boost, not the version shipped with mongodb"

  depends_on "boost" => :optional
  depends_on :macos => :snow_leopard
  depends_on "scons" => :build
  depends_on "openssl" => :optional

  # Review this patch with each release.
  # This modifies the SConstruct file to include 10.10 as an accepted build option.
  if MacOS.version == :yosemite
    patch do
      url "https://raw.githubusercontent.com/DomT4/scripts/fbc0cda/Homebrew_Resources/Mongodb/mongoyosemite.diff"
      sha1 "f4824e93962154aad375eb29527b3137d07f358c"
    end
  end

  def install
    args = %W[
      --prefix=#{prefix}
      -j#{ENV.make_jobs}
      --cc=#{ENV.cc}
      --cxx=#{ENV.cxx}
      --osx-version-min=#{MacOS.version}
    ]

    # --full installs development headers and client library, not just binaries
    # (only supported pre-2.7)
    args << "--full" if build.stable?
    args << "--use-system-boost" if build.with? "boost"
    args << "--64" if MacOS.prefer_64_bit?

    if build.with? "openssl"
      args << "--ssl" << "--extrapath=#{Formula["openssl"].opt_prefix}"
    end

    scons "install", *args

    (buildpath+"mongod.conf").write mongodb_conf
    etc.install "mongod.conf"

    (var+"mongodb").mkpath
    (var+"log/mongodb").mkpath
  end

  def mongodb_conf; <<-EOS.undent
    systemLog:
      destination: file
      path: #{var}/log/mongodb/mongo.log
      logAppend: true
    storage:
      dbPath: #{var}/mongodb
    net:
      bindIp: 127.0.0.1
    EOS
  end

  test do
    system "#{bin}/mongod", "--sysinfo"
  end
end
