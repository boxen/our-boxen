# Make all the fancy `hub` shortcuts available via `git`.

eval "$(hub alias -s)"
