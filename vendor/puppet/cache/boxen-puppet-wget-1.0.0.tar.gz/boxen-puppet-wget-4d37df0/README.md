# WGet Puppet Module for Boxen

Requires the following boxen modules:

## Usage

```puppet
include wget
```

## Required Puppet Modules

* boxen
* homebrew

