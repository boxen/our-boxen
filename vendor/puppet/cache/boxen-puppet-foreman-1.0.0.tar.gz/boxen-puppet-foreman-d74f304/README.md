# Puppet module for Foreman

Installs foreman.

## Usage

```
include foreman
```

## Required modules

* boxen (OS X only)
