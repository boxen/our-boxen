export GH_NVM_DEFAULT_VERSION="v0.8"
export GH_NVM_DIR=$GH_HOME/nvm

# Add NPM's local bins to the path.

export PATH=node_modules/.bin:$PATH
